"""PlayPulse desktop application package."""
